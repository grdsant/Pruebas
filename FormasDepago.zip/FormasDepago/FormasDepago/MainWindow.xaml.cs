﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;
using System.IO;
using System.Drawing;
using Color = System.Drawing.Color;
using MessageBox = System.Windows.Forms.MessageBox;
using System.Windows.Controls.Primitives;
using TextBox = System.Windows.Controls.TextBox;
using DataGridCell = System.Windows.Controls.DataGridCell;
using DataGrid = System.Windows.Controls.DataGrid;
using MahApps.Metro.Controls;

namespace FormasDepago
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 

    public partial class MainWindow : System.Windows.Window
    {
        public static string VarFechaInicial { get; set; }
        public static string VarFechaFinal   { get; set; }

        public static string VarNombre { get; set; }
        public static string VarUsuario { get; set; }
        public static string VarPassword { get; set; }

        //int nr;
        #region Variables
        decimal sum02 = 0;
        decimal sum03 = 0;
        decimal sum04 = 0;
        decimal sum05 = 0;
        decimal sum06 = 0;
        decimal sum07 = 0;
        decimal sum08 = 0;
        decimal sum09 = 0;
        decimal sum10 = 0;
        decimal sum11 = 0;
        decimal sum12 = 0;
        decimal sum13 = 0;
        decimal sum14 = 0;
        decimal sum15 = 0;
        decimal sum16 = 0;
        decimal sum17 = 0;
        decimal sum18 = 0;
        decimal sum19 = 0;
        decimal sum20 = 0;
        decimal sum21 = 0;
        decimal sum22 = 0;
        decimal sum23 = 0;
        decimal sum24 = 0;
        decimal sum25 = 0;
        decimal sum26 = 0;
        decimal sum27 = 0;
        decimal sum28 = 0;
        decimal sum29 = 0;
        decimal sum30 = 0;
        decimal sum31 = 0;
        decimal sum32 = 0;
        decimal sum33 = 0;
        decimal sum34 = 0;
        decimal sum35 = 0;
        decimal sum36 = 0;
        decimal sum37 = 0;
        decimal sum38 = 0;
        decimal sum39 = 0;
        decimal sum40 = 0;
        decimal sum41 = 0;
        decimal sum42 = 0;
        decimal sum43 = 0;
        decimal sum44 = 0;
        decimal sum45 = 0;
        decimal sum46 = 0;
        decimal sum47 = 0;
        decimal sum48 = 0;
        decimal sum49 = 0;
        decimal sum50 = 0;
        decimal sum51 = 0;
        decimal sum52 = 0;
        decimal sum53 = 0;
        decimal sum54 = 0;
        decimal sum55 = 0;
        decimal sum56 = 0;
        decimal sum57 = 0;
        decimal sum58 = 0;
        decimal sum59 = 0;
        decimal sum60 = 0;
        decimal sum61 = 0;
        decimal sum62 = 0;
        decimal sum63 = 0;
        decimal sum64 = 0;
        decimal sum65 = 0;
        decimal sum66 = 0;
        decimal sum67 = 0;
        decimal sum68 = 0;
        decimal sum69 = 0;
        decimal sum70 = 0;
        #endregion

        string tienda = string.Empty;
        string nivel = string.Empty;

        public static int cont;
        public static int cont1;
        public System.Data.DataTable dtDatos = null;

        public MainWindow()
        {
            InitializeComponent();

            double widthPrimary = System.Windows.SystemParameters.PrimaryScreenWidth;
            double heightPrimary = System.Windows.SystemParameters.PrimaryScreenHeight;

            double widthArea = System.Windows.SystemParameters.WorkArea.Height;
            double heightArea = System.Windows.SystemParameters.WorkArea.Width;

            double widthThis = this.Width;
            double heihgtThis = this.Height;

            dgDatos.MaxWidth = widthThis - 40;
            dgDatos.MaxHeight = heihgtThis - 120;

            dgDatos.Visibility = Visibility.Hidden;

        }

        private void Window_Initialized(object sender, EventArgs e)
        {
            //MessageBox.Show("Inicializa");
            
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
        }

        protected void BindTiendas()
        {
            try
            {
                cbTiendas.ItemsSource = Fdp.Negocio.FormasDepago.FormasDepago.GetInstance().ObtenTiendas().ToList();
                cbTiendas.DisplayMemberPath = "Value";
                cbTiendas.SelectedValue     = "Key";
                cbTiendas.SelectedIndex  = 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void FechaInicial_CalendarClosed(object sender, RoutedEventArgs e)
        {
            string fechainicialC = FechaFinal.Text;
        }

        private void FechaInicial_Initialized(object sender, EventArgs e)
        {
            DateTime fecha = DateTime.Now;
            fecha = fecha.AddDays(-1);
            FechaInicial.Text = fecha.ToString("dd/MM/yyyy");
        }

        private void FechaFinal_Initialized(object sender, EventArgs e)
        {
            DateTime fecha = DateTime.Now;
            FechaFinal.Text = fecha.ToString("dd/MM/yyyy");
        }

        private void FechaFinal_CalendarClosed(object sender, RoutedEventArgs e)
        {
            string fechafinalC = FechaFinal.Text;
        }

        private void btMinimizar_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void btMaximizar_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Maximized)
            {
                WindowState = WindowState.Normal;
            }
            else          
            {
                WindowState = WindowState.Maximized;
            }
        }

        private void btCerrar_Click(object sender, RoutedEventArgs e)
        {
            App.Current.Shutdown();
        }

        private void btProcesar_Click(object sender, RoutedEventArgs e)
        {
                cont = cont + 1;
            if (cont < 2)
            {
                FechasProceso objeto = new FechasProceso(cont);
                objeto.Show();
            }
            else
            {
                //System.Windows.MessageBox.Show("La ventana ya esta abierta...");
                Card01.Visibility = Visibility;
                btCerrarAbieta.Focus();
            }
        }

        private void btRecargar_Click(object sender, RoutedEventArgs e)
        {

            // Carga de Datos
            try
            {
                BinDatos();
            }
            catch { }
        }

        protected void BinDatos()
        {
            try
            {
                string fechainicialC = FechaInicial.Text;
                fechainicialC = fechainicialC.Substring(8, 2) + fechainicialC.Substring(3, 2) + fechainicialC.Substring(0, 2);
                string fechafinalC = FechaFinal.Text;
                fechafinalC = fechafinalC.Substring(8, 2) + fechafinalC.Substring(3, 2) + fechafinalC.Substring(0, 2);

                FormasDepago.MainWindow.VarFechaInicial = fechainicialC;
                FormasDepago.MainWindow.VarFechaFinal = fechafinalC;
                FormasDepago.TrxVentas.VarFechaInicial = fechainicialC;
                FormasDepago.TrxVentas.VarFechaFinal = fechafinalC;

                string usuario = FormasDepago.MainWindow.VarUsuario;

                if (nivel == "Tienda") { nivel = "2"; };
                if (nivel == "Mes")    { nivel = "3"; };
                if (nivel == "Día")    { nivel = "1"; };

                dtDatos = null;
                dgDatos.ItemsSource = null;

                ProgCirculo.IsIndeterminate = true;
                dtDatos = Fdp.Negocio.FormasDepago.FormasDepago.GetInstance().ObtenDatos(fechainicialC, fechafinalC, tienda, nivel, usuario);
                ProgCirculo.IsIndeterminate = false;
            }
            catch { }

            if (dtDatos != null)
            {
                if (dtDatos.Rows.Count > 0)
                {
                    dgDatos.Visibility = Visibility.Visible;

                    lbTitulo.Content = " Formas de pago" + " / " + dtDatos.Rows.Count + " Registros";
                    dgDatos.ItemsSource = null;

                    dgDatos.ItemsSource = dtDatos.DefaultView;

                    SetFontAndcolors();
                    RowStyle();


                }
                else
                {
                    dgDatos.Visibility = Visibility.Hidden;
                }
            }
        }

        private void SetFontAndcolors()
        {
            //dgDatos.Columns["CUPSTR"].Width = 80;
            //dgDatos.Columns[1].Width = 80;
            //dgDatos.Columns[2].Width = 80;
            //dgDatos.Columns[3].Width = 80;
            //dgDatos.Columns[4].Width = 80;
            //dgDatos.Columns[5].Width = 80;

            dgDatos.Columns[8].Visibility = Visibility.Hidden;
            dgDatos.Columns[9].Visibility = Visibility.Hidden;
        }

        private void RowStyle()
        {
            if (nivel == "3")
            {
                dgDatos.Columns[1].Visibility = Visibility.Visible;
                dgDatos.Columns[2].Visibility = Visibility.Hidden;
            }
            else
            if (nivel == "1")
            {
                dgDatos.Columns[1].Visibility = Visibility.Hidden;
                dgDatos.Columns[2].Visibility = Visibility.Visible;
            }
            else
            if (nivel == "2")
            {
                dgDatos.Columns[1].Visibility = Visibility.Hidden;
                dgDatos.Columns[2].Visibility = Visibility.Hidden;
            }
            else
            {
                dgDatos.Columns[1].Visibility = Visibility.Visible;
                dgDatos.Columns[1].Visibility = Visibility.Visible;
            }

            Inicializa();

            foreach (DataRowView item in dgDatos.ItemsSource)
            {
                #region Asignacion
                //if (nivel == "1")
                //{
                    sum02 += Convert.ToDecimal(item[02].ToString());
                //}
                sum03 += Convert.ToDecimal(item[03].ToString());
                sum04 += Convert.ToDecimal(item[04].ToString());
                sum05 += Convert.ToDecimal(item[05].ToString());
                sum06 += Convert.ToDecimal(item[06].ToString());
                sum07 += Convert.ToDecimal(item[07].ToString());
                sum08 += Convert.ToDecimal(item[08].ToString());
                sum09 += Convert.ToDecimal(item[09].ToString());
                sum10 += Convert.ToDecimal(item[10].ToString());
                sum11 += Convert.ToDecimal(item[11].ToString());
                sum12 += Convert.ToDecimal(item[12].ToString());
                sum13 += Convert.ToDecimal(item[13].ToString());
                sum14 += Convert.ToDecimal(item[14].ToString());
                sum15 += Convert.ToDecimal(item[15].ToString());
                sum16 += Convert.ToDecimal(item[16].ToString());
                sum17 += Convert.ToDecimal(item[17].ToString());
                sum18 += Convert.ToDecimal(item[18].ToString());
                sum19 += Convert.ToDecimal(item[19].ToString());
                sum20 += Convert.ToDecimal(item[20].ToString());
                sum21 += Convert.ToDecimal(item[21].ToString());
                sum22 += Convert.ToDecimal(item[22].ToString());
                sum23 += Convert.ToDecimal(item[23].ToString());
                sum24 += Convert.ToDecimal(item[24].ToString());
                sum25 += Convert.ToDecimal(item[25].ToString());
                sum26 += Convert.ToDecimal(item[26].ToString());
                sum27 += Convert.ToDecimal(item[27].ToString());
                sum28 += Convert.ToDecimal(item[28].ToString());
                sum29 += Convert.ToDecimal(item[29].ToString());
                sum30 += Convert.ToDecimal(item[30].ToString());
                sum31 += Convert.ToDecimal(item[31].ToString());
                sum32 += Convert.ToDecimal(item[32].ToString());
                sum33 += Convert.ToDecimal(item[33].ToString());
                sum34 += Convert.ToDecimal(item[34].ToString());
                sum35 += Convert.ToDecimal(item[35].ToString());
                sum36 += Convert.ToDecimal(item[36].ToString());
                sum37 += Convert.ToDecimal(item[37].ToString());
                sum38 += Convert.ToDecimal(item[38].ToString());
                sum39 += Convert.ToDecimal(item[39].ToString());
                sum40 += Convert.ToDecimal(item[40].ToString());
                sum41 += Convert.ToDecimal(item[41].ToString());
                sum42 += Convert.ToDecimal(item[42].ToString());
                sum43 += Convert.ToDecimal(item[43].ToString());
                sum44 += Convert.ToDecimal(item[44].ToString());
                sum45 += Convert.ToDecimal(item[45].ToString());
                sum46 += Convert.ToDecimal(item[46].ToString());
                sum47 += Convert.ToDecimal(item[47].ToString());
                sum48 += Convert.ToDecimal(item[48].ToString());
                sum49 += Convert.ToDecimal(item[49].ToString());
                sum50 += Convert.ToDecimal(item[50].ToString());
                sum51 += Convert.ToDecimal(item[51].ToString());
                sum52 += Convert.ToDecimal(item[52].ToString());
                sum53 += Convert.ToDecimal(item[53].ToString());
                sum54 += Convert.ToDecimal(item[54].ToString());
                sum55 += Convert.ToDecimal(item[55].ToString());
                sum56 += Convert.ToDecimal(item[56].ToString());
                sum57 += Convert.ToDecimal(item[57].ToString());
                sum58 += Convert.ToDecimal(item[58].ToString());
                sum59 += Convert.ToDecimal(item[59].ToString());
                sum60 += Convert.ToDecimal(item[60].ToString());
                sum61 += Convert.ToDecimal(item[61].ToString());
                sum62 += Convert.ToDecimal(item[62].ToString());
                sum63 += Convert.ToDecimal(item[63].ToString());
                sum64 += Convert.ToDecimal(item[64].ToString());
                sum65 += Convert.ToDecimal(item[65].ToString());
                sum66 += Convert.ToDecimal(item[66].ToString());
                sum67 += Convert.ToDecimal(item[67].ToString());
                sum68 += Convert.ToDecimal(item[68].ToString());
                sum69 += Convert.ToDecimal(item[69].ToString());
                if (nivel != "1")
                {
                    sum70 += Convert.ToDecimal(item[70].ToString());
                }
                //sum69 += Convert.ToDecimal(item[69].ToString());
                //sum70 += Convert.ToDecimal(item[70].ToString());
                #endregion 

                if (item[0].ToString() == "99999")
                {
                    #region Asignacion
                    if (nivel == "1")
                    {
                        item[02] = 0; // 
                    }
                    item[03] = sum03; // Piezas
                    item[04] = sum04; // Cant Tickets
                    item[05] = sum05; // Ticket Precio Promedio

                    if (sum04 != 0)
                    {
                        item[06] = sum03 / sum04; // Indice Ventas
                    }
                    else
                    {
                        item[06] = 0;
                    }

                    item[07] = sum07; // costo 
                    item[08] = sum08; // si emite cupon
                    item[09] = sum09; // no emite cupon
                    item[10] = sum10; // Venta Contado
                    item[11] = sum11; // Venta Mayoristas
                    item[12] = sum12; // Venta Empleado 
                    item[13] = sum13; // Dev Regular 
                    item[14] = sum14; // Dev Empleado 
                    item[15] = sum15; // Descuento Devolucion Mayorista
                    item[16] = sum16; // Rebajas Descuento
                    item[17] = sum17; // Abarrotes con Iva
                    item[18] = sum18; // Abarrotes sin Iva

                    decimal ventaNeta = 0;
                    ventaNeta = sum10 + sum11 + sum12 + sum13 + sum14 + sum15 + sum16;
                    item[19] = ventaNeta;
                    if (sum05 != 0)
                    {
                        item[05] = ventaNeta / sum05;
                    }
                    else
                    {
                        item[05] = 0;
                    }

                    //item[19] = sum19; // VentaNeta Neta
                    decimal ivaTiempoAire = 0;
                    ivaTiempoAire = sum20 - sum22;
                    item[20] = ivaTiempoAire; // Iva Venta Neta
                    item[21] = sum21; // 21 Venta Tiempo aire
                    item[22] = sum22; // 22 Iva Tiempo Aire
                    item[23] = sum23; // 23 Servicios
                    item[24] = sum24; // 24 Comision Servicios
                    item[25] = sum25; // 25 Apartados 
                    item[26] = sum26; // 26 Apartados Cedidos
                    item[27] = sum27; // 27 Total Apartados
                    item[28] = sum28; // 28 Abonos Apartados liqui
                    item[29] = sum29; // 29 Egresos
                    item[30] = sum30; // 30 Egresos Prestamo Emple
                    item[31] = sum31; // 31 Egresos Pago Nomina
                    item[32] = sum32; // 32 Egresos Pago Luz
                    item[33] = sum33; // 33 Egresos Viaticos
                    item[34] = sum34; // 34 Egresos Gastos Publici
                    item[35] = sum35; // 35 Egresos Diferencia Nom
                    item[36] = sum36; // 36 Egresos Mantto Tienda
                    item[37] = sum37; // 37 Egresos Serv Sistemas 
                    item[38] = sum38; // 38 Pago Tarjeta Mel-Mil
                    item[39] = sum39; // 39 Pago Mayoristas
                    item[40] = sum40; // 40 Retiros Parciales
                    item[41] = sum41; // 41 Comision Mayoristas
                    item[42] = sum42; // 42 Cupones
                    item[43] = sum43; // 43 Cupon Pre Impresos
                    item[44] = sum44; // 44 Nota Credito Emitida
                    item[45] = sum45; // 45 Nota Credito Canjeada
                    item[46] = sum46; // 46 Certif. Regalo Canjead 
                    item[47] = sum47; // 47 Certif. Regalo Venta
                    item[48] = sum48; // 48 Pago Efectivo
                    item[49] = sum49; // 49 Tarjetas Bancarias
                    item[50] = sum50; // 50 Tarjetas Visa

                    item[51] = sum51; // 51 Tarjetas Visa
                    item[52] = sum52; // 52 Tarjetas Visa

                    item[53] = sum53; // 53 51 Tarjetas Master Card
                    item[54] = sum54; // 54 52 Tarjetas Melody Milano
                    item[55] = sum55; // 55 53 Otras Tarjetas
                    item[56] = sum56; // 56 54 Credimax
                    item[57] = sum57; // 57 55 Ingresos Dif Vales
                    item[58] = sum58; // 58 56 Vales
                    item[59] = sum59; // 59 57 Edenred
                    item[60] = sum60; // 60 58 Si Vale
                    item[61] = sum61; // 61 59 Servi-Bono
                    item[62] = sum62; // 62 60 Sodexho
                    item[63] = sum63; // 63 61 Efectivale
                    item[64] = sum64; // 64 62 Conaco Campeche
                    item[65] = sum65; // 65 63 Ecovale Opam
                    item[66] = sum66; // 66 64 Milano Melody 
                    item[67] = sum67; // 67 65 MonteMex
                    item[68] = sum68; // 68 66 Fonacot
                    item[69] = sum69; // 69 67 Venta Empresarial
                    item[70] = sum70; // 70 68 Finan Apart Myr
                    //item[69] = sum69;
                    //item[70] = sum70;
                    #endregion

                    var row = dgDatos.ItemContainerGenerator.ContainerFromItem(item) as DataGridRow;
                    //if (item[0].ToString() == "99999")
                    //{
                        row.Background = System.Windows.Media.Brushes.Green;
                    //}
                }
            }
        }

        private void Inicializa()
        {
            #region Variables
            //if (nivel == "1")
            //{
            sum02 = 0;
            //}
             sum03 = 0;
             sum04 = 0;
             sum05 = 0;
             sum06 = 0;
             sum07 = 0;
             sum08 = 0;
             sum09 = 0;
             sum10 = 0;
             sum11 = 0;
             sum12 = 0;
             sum13 = 0;
             sum14 = 0;
             sum15 = 0;
             sum16 = 0;
             sum17 = 0;
             sum18 = 0;
             sum19 = 0;
             sum20 = 0;
             sum21 = 0;
             sum22 = 0;
             sum23 = 0;
             sum24 = 0;
             sum25 = 0;
             sum26 = 0;
             sum27 = 0;
             sum28 = 0;
             sum29 = 0;
             sum30 = 0;
             sum31 = 0;
             sum32 = 0;
             sum33 = 0;
             sum34 = 0;
             sum35 = 0;
             sum36 = 0;
             sum37 = 0;
             sum38 = 0;
             sum39 = 0;
             sum40 = 0;
             sum41 = 0;
             sum42 = 0;
             sum43 = 0;
             sum44 = 0;
             sum45 = 0;
             sum46 = 0;
             sum47 = 0;
             sum48 = 0;
             sum49 = 0;
             sum50 = 0;
             sum51 = 0;
             sum52 = 0;
             sum53 = 0;
             sum54 = 0;
             sum55 = 0;
             sum56 = 0;
             sum57 = 0;
             sum58 = 0;
             sum59 = 0;
             sum60 = 0;
             sum61 = 0;
             sum62 = 0;
             sum63 = 0;
             sum64 = 0;
             sum65 = 0;
             sum66 = 0;
             sum67 = 0;
             sum68 = 0;
             sum69 = 0;
             sum70 = 0;
            #endregion
        }

        private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            double widthThis = this.Width;
            double heihgtThis = this.Height;

            try
            {
                dgDatos.MaxWidth = widthThis - 40;
                dgDatos.MaxHeight = heihgtThis - 120;
            }
            catch { }
        }

        private void LbTitulo_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (WindowState == WindowState.Maximized)
            {
                WindowState = WindowState.Normal;
            }
            else
            {
                WindowState = WindowState.Maximized;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Card01.Visibility = Visibility.Hidden;
        }

        private void btExportar_Click(object sender, RoutedEventArgs e)
        {
            CargaExcel();
        }

        private void CargaExcel()
        {
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            if (xlApp == null)
            {
                System.Windows.MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            int nc = dgDatos.Columns.Count;


            for (int ii = 1; ii <= nc; ii++)
            {
                xlWorkSheet.Cells[1, ii] = dgDatos.Columns[ii - 1].Header;
            }

            int nr = dgDatos.Items.Count;

            int r = 0;
            int rt = 3;
            foreach (DataRow row in dtDatos.Rows)
            {
                var gsArray = new[]       {
                            row["CUPSTR"], // 01
                            row["CUPMES"], // 02
                            row["CUPFCH"], // 03
                            row["CUPQTY"], // 04
                            row["CUPNTI"], // 05
                            row["CUPTPP"], // 06
                            row["CUPINV"], // 07
                            row["CUPCST"], // 08
                            row["CUPVSE"], // 09
                            row["CUPVNE"], // 10
                            row["CUPVTC"], // 11
                            row["CUPVTM"], // 12
                            row["CUPVTE"], // 13
                            row["CUPDVC"], // 14
                            row["CUPDVE"], // 15
                            row["CUPDSM"], // 16
                            row["CUPRBD"], // 17
                            row["CUPABI"], // 18
                            row["CUPASI"], // 19
                            row["CUPVTN"], // 20
                            row["CUPIVN"], // 21
                            row["CUPVTA"], // 22
                            row["CUPITA"], // 23
                            row["CUPSRV"], // 24
                            row["CUPCSV"], // 25
                            row["CUPDAA"], // 26
                            row["CUPDAC"], // 27
                            row["CUPTOA"], // 28
                            row["CUPFLA"], // 29
                            row["CUPEGR"], // 30
                            row["CUPEPE"], // 31
                            row["CUPEPN"], // 32
                            row["CUPEPL"], // 33
                            row["CUPEVI"], // 34
                            row["CUPEGP"], // 35
                            row["CUPEDN"], // 36
                            row["CUPEMT"], // 37
                            row["CUPESS"], // 38
                            row["CUPPTM"], // 39
                            row["CUPPCM"], // 40
                            row["CUPDRP"], // 41
                            row["CUPCMY"], // 42
                            row["CUPFCP"], // 43
                            row["CUPFHC"], // 44
                            row["CUPFDB"], // 45
                            row["CUPFDR"], // 46
                            row["CUPFGC"], // 47
                            row["CUPVCR"], // 48
                            row["CUPFCA"], // 49
                            row["CUPFTB"], // 50
                            row["CUPTVI"], // 51
                              row["CUPTDE"], // 52 51
                              row["CUPTCR"], // 53 51
                            row["CUPTMC"], // 54 52
                            row["CUPTMM"], // 55 53
                            row["CUPTTC"], // 56 54
                            row["CUPFCM"], // 57 55
                            row["CUPIXD"], // 58 56
                            row["CUPFVL"], // 59 57
                            row["CUPFV1"], // 60 58
                            row["CUPFV2"], // 61 59
                            row["CUPFV3"], // 62 60
                            row["CUPFV4"], // 63 61
                            row["CUPFV5"], // 64 62
                            row["CUPFV6"], // 65 63
                            row["CUPFV7"], // 66 64
                            row["CUPFV8"], // 67 65
                            row["CUPFV9"], // 68 66
                            row["CUPFFA"], // 69 67
                            row["CUPFVE"], // 70 68
                            row["CUPFFN"], // 71 69
                            row["CUPMAR"]  // 72 70
                };

                Range rng = xlWorkSheet.get_Range("A" + rt, "BT" + rt);
                rng.Value = gsArray;

                lbTitulo.Content = " Formas de Pago" + " / " + (r += 1).ToString() ;

                rt++;
            }
            xlWorkSheet.Columns[1].ColumnWidth  = 05;
            xlWorkSheet.Columns[2].ColumnWidth  = 10;
            xlWorkSheet.Columns[3].ColumnWidth  = 10;
            xlWorkSheet.Columns[4].ColumnWidth  = 05;
            xlWorkSheet.Columns[5].ColumnWidth  = 10;
            xlWorkSheet.Columns[6].ColumnWidth  = 15;
            xlWorkSheet.Columns[7].ColumnWidth  = 10;
            xlWorkSheet.Columns[8].ColumnWidth  = 15;
            xlWorkSheet.Columns[9].ColumnWidth  = 15;
            xlWorkSheet.Columns[10].ColumnWidth = 15;
            xlWorkSheet.Columns[11].ColumnWidth = 10;
            xlWorkSheet.Columns[12].ColumnWidth = 10;
            xlWorkSheet.Columns[13].ColumnWidth = 10;
            xlWorkSheet.Columns[14].ColumnWidth = 10;
            xlWorkSheet.Columns[15].ColumnWidth = 10;
            xlWorkSheet.Columns[16].ColumnWidth = 10;
            xlWorkSheet.Columns[17].ColumnWidth = 10;
            xlWorkSheet.Columns[18].ColumnWidth = 10;
            xlWorkSheet.Columns[19].ColumnWidth = 10;
            xlWorkSheet.Columns[20].ColumnWidth = 15;
            xlWorkSheet.Columns[21].ColumnWidth = 15;
            xlWorkSheet.Columns[22].ColumnWidth = 15;
            xlWorkSheet.Columns[23].ColumnWidth = 15;
            xlWorkSheet.Columns[24].ColumnWidth = 10;
            xlWorkSheet.Columns[25].ColumnWidth = 10;
            xlWorkSheet.Columns[26].ColumnWidth = 10;
            xlWorkSheet.Columns[27].ColumnWidth = 10;
            xlWorkSheet.Columns[28].ColumnWidth = 10;
            xlWorkSheet.Columns[29].ColumnWidth = 10;
            xlWorkSheet.Columns[30].ColumnWidth = 10;
            xlWorkSheet.Columns[31].ColumnWidth = 10;
            xlWorkSheet.Columns[32].ColumnWidth = 10;
            xlWorkSheet.Columns[33].ColumnWidth = 10;
            xlWorkSheet.Columns[34].ColumnWidth = 10;
            xlWorkSheet.Columns[35].ColumnWidth = 10;
            xlWorkSheet.Columns[36].ColumnWidth = 10;
            xlWorkSheet.Columns[37].ColumnWidth = 10;
            xlWorkSheet.Columns[38].ColumnWidth = 10;
            xlWorkSheet.Columns[39].ColumnWidth = 10;
            xlWorkSheet.Columns[40].ColumnWidth = 10;
            xlWorkSheet.Columns[41].ColumnWidth = 10;
            xlWorkSheet.Columns[42].ColumnWidth = 10;
            xlWorkSheet.Columns[43].ColumnWidth = 10;
            xlWorkSheet.Columns[44].ColumnWidth = 10;
            xlWorkSheet.Columns[45].ColumnWidth = 10;
            xlWorkSheet.Columns[46].ColumnWidth = 10;
            xlWorkSheet.Columns[47].ColumnWidth = 10;
            xlWorkSheet.Columns[48].ColumnWidth = 10;
            xlWorkSheet.Columns[49].ColumnWidth = 15;
            xlWorkSheet.Columns[50].ColumnWidth = 15;
            xlWorkSheet.Columns[51].ColumnWidth = 15;
            xlWorkSheet.Columns[52].ColumnWidth = 15;
            xlWorkSheet.Columns[53].ColumnWidth = 15;
            xlWorkSheet.Columns[54].ColumnWidth = 15;
            xlWorkSheet.Columns[55].ColumnWidth = 10;
            xlWorkSheet.Columns[56].ColumnWidth = 10;
            xlWorkSheet.Columns[57].ColumnWidth = 10;
            xlWorkSheet.Columns[58].ColumnWidth = 10;
            xlWorkSheet.Columns[59].ColumnWidth = 10;
            xlWorkSheet.Columns[60].ColumnWidth = 10;
            xlWorkSheet.Columns[61].ColumnWidth = 10;
            xlWorkSheet.Columns[62].ColumnWidth = 10;
            xlWorkSheet.Columns[63].ColumnWidth = 10;
            xlWorkSheet.Columns[64].ColumnWidth = 10;
            xlWorkSheet.Columns[65].ColumnWidth = 10;
            xlWorkSheet.Columns[66].ColumnWidth = 10;
            xlWorkSheet.Columns[67].ColumnWidth = 10;
            xlWorkSheet.Columns[68].ColumnWidth = 10;
            xlWorkSheet.Columns[69].ColumnWidth = 10;

            var Rang01 = xlWorkSheet.get_Range("A1", "C1");
            Rang01.Interior.Color = Color.LightGray;

            var Rang02 = xlWorkSheet.get_Range("D1", "G1");
            Rang02.Interior.Color = Color.LightSkyBlue;

            var Rang03 = xlWorkSheet.get_Range("H1", "H1");
            Rang03.Interior.Color = Color.Gray;

            var Rang04 = xlWorkSheet.get_Range("I1", "J1");
            Rang04.Interior.Color = Color.LightGray;

            var Rang05 = xlWorkSheet.get_Range("K1", "M1");
            Rang05.Interior.Color = Color.LightSkyBlue;

            var Rang06 = xlWorkSheet.get_Range("N1", "P1");
            Rang06.Interior.Color = Color.Gray;

            var Rang07 = xlWorkSheet.get_Range("Q1", "Q1");
            Rang07.Interior.Color = Color.LightGray;

            var Rang08 = xlWorkSheet.get_Range("R1", "S1");
            Rang08.Interior.Color = Color.LightSkyBlue;

            var Rang09 = xlWorkSheet.get_Range("T1", "W1");
            Rang09.Interior.Color = Color.LightGreen;

            var Rang10 = xlWorkSheet.get_Range("X1", "Y1");
            Rang10.Interior.Color = Color.LightSalmon;

            var Rang11 = xlWorkSheet.get_Range("Z1", "AC1");
            Rang11.Interior.Color = Color.LightSkyBlue;

            var Rang12 = xlWorkSheet.get_Range("AD1", "AL1");
            Rang12.Interior.Color = Color.LightSkyBlue;

            var Rang13 = xlWorkSheet.get_Range("AM1", "AN1");
            Rang13.Interior.Color = Color.LightSkyBlue;

            var Rang14 = xlWorkSheet.get_Range("AO1", "AR1");
            Rang14.Interior.Color = Color.LightGray;

            var Rang15 = xlWorkSheet.get_Range("AS1", "AT1");
            Rang15.Interior.Color = Color.LightSkyBlue;

            var Rang16 = xlWorkSheet.get_Range("AU1", "AV1");
            Rang16.Interior.Color = Color.LightGray;

            var Rang17 = xlWorkSheet.get_Range("AW1", "AW1");
            Rang17.Interior.Color = Color.LightGreen;

            var Rang18 = xlWorkSheet.get_Range("AX1", "BB1");
            Rang18.Interior.Color = Color.LightSkyBlue;

            var Rang19 = xlWorkSheet.get_Range("BC1", "BC1");
            Rang19.Interior.Color = Color.Gray;

            var Rang20 = xlWorkSheet.get_Range("BD1", "BE1");
            Rang20.Interior.Color = Color.LightGreen;

            var Rang21 = xlWorkSheet.get_Range("BF1", "BQ1");
            Rang21.Interior.Color = Color.LightSkyBlue;

            var Rang22 = xlWorkSheet.get_Range("BF1", "BQ1");
            Rang22.Interior.Color = Color.LightGray;

            var Rang24 = xlWorkSheet.get_Range("BR1", "BT1");
            Rang24.Interior.Color = Color.LightGray;

            var Rang23 = xlWorkSheet.get_Range("A1", "BT1");
            Rang23.WrapText = true;
            Rang23.Font.Bold = true;
            Rang23.Font.Color = Color.White;
            Rang23.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang23.Font.Underline = true;
            //Rang23.HorizontalAlignment = AlignmentX.Left;
            //Rang02.HorizontalAlignment = XlHAlign.xlHAlignCenter;

            String Rango = "A2" + ":" + "BT" + rt;
            Excel.Range SourceRange = (Excel.Range)xlWorkSheet.get_Range("A2", "BT" + rt); // or whatever range you want here
            FormatAsTable(SourceRange, "Table1", "TableStyleMedium2");

            xlWorkSheet.Rows[2].Hidden = true;

            xlWorkSheet.Columns["A:C"].HorizontalAlignment  = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["D:BQ"].HorizontalAlignment = XlHAlign.xlHAlignRight;
            xlWorkSheet.Columns["BT"].HorizontalAlignment   = XlHAlign.xlHAlignCenter;

            xlWorkSheet.Columns["A:B"].NumberFormat = "#####";
            xlWorkSheet.Columns["C"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["D:E"].NumberFormat = "###,###";
            xlWorkSheet.Columns["F:BT"].NumberFormat = "###,###.00";

            var range = xlWorkSheet.get_Range("A3", "A3");
            range.Select();

            xlApp.Range["I:J"].EntireColumn.Delete(); //Temporal

            string Hoy = DateTime.Now.ToString("yyyyMMddHHmmss");
            xlApp.ActiveWindow.Zoom = 80;
            xlWorkBook.SaveAs("C:\\Reportes\\FormasdePago" + Hoy + ".xlsx", Excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);

            string comando = @"C:\\Reportes\\FormasdePago" + Hoy + ".xlsx";
            ExecuteCommand(comando);
        }

        static void ExecuteCommand(string _Command)
        {
            //Indicamos que deseamos inicializar el proceso cmd.exe junto a un comando de arranque. 
            //(/C, le indicamos al proceso cmd que deseamos que cuando termine la tarea asignada se cierre el proceso).
            //Para mas informacion consulte la ayuda de la consola con cmd.exe /? 
            System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + _Command);
            // Indicamos que la salida del proceso se redireccione en un Stream
            procStartInfo.RedirectStandardOutput = true;
            procStartInfo.UseShellExecute = false;
            //Indica que el proceso no despliegue una pantalla negra (El proceso se ejecuta en background)
            procStartInfo.CreateNoWindow = true;
            //Inicializa el proceso
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            //Consigue la salida de la Consola(Stream) y devuelve una cadena de texto
            string result = proc.StandardOutput.ReadToEnd();
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        public void FormatAsTable(Excel.Range SourceRange, string TableName, string TableStyleName)
        {
            SourceRange.Worksheet.ListObjects.Add(XlListObjectSourceType.xlSrcRange,
            SourceRange, System.Type.Missing, XlYesNoGuess.xlYes, System.Type.Missing).Name =
                TableName;
            SourceRange.Select();
            SourceRange.Worksheet.ListObjects[TableName].TableStyle = TableStyleName;
            SourceRange.Worksheet.ListObjects[TableName].ShowAutoFilter = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowHeaders = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowTotals = false;
        }

        private void Button_LostFocus(object sender, RoutedEventArgs e)
        {
            Card01.Visibility = Visibility.Hidden;
        }

        private void cbTiendas_Loaded(object sender, RoutedEventArgs e)
        {
            // Carga de Tiendas
            try
            {
                BindTiendas();
            }
            catch { }
        }

        private void FechaFinal_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            // Carga de Tiendas
            try
            {
                BinDatos();
            }
            catch { }
        }

        private void FechaInicial_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            // Carga de Tiendas
            try
            {
                BinDatos();
            }
            catch { }
        }

        private void cbTiendas_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                // Carga de Datos
                try
                {
                    BinDatos();
                }
                catch { }
            }
        }

        private void cbNivel_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                // Carga de Datos
                try
                {
                    BinDatos();
                }
                catch { }
            }
        }

        private void FechaInicial_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                // Carga de Datos
                try
                {
                    BinDatos();
                }
                catch { }
            }
        }

        private void FechaFinal_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                // Carga de Datos
                try
                {
                    BinDatos();
                }
                catch { }
            }
        }

        private void cbTiendas_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                string[] arr;
                arr = cbTiendas.SelectedValue.ToString().Split();
                tienda = arr[1];
            }
            catch { }

            // Carga de Tiendas
            try
            {
                BinDatos();
            }
            catch { }
        }

        private void cbNivel_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                string[] arr;
                arr = cbNivel.SelectedValue.ToString().Split();
                nivel = arr[2];
            }
            catch { }
        
            // Carga de Tiendas
            try
            {
                BinDatos();
            }
            catch { }
        }


        /// <summary>
        ///  Funciones de consulta nivel de talle
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        
        private void Row_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            DataGridRow row = sender as DataGridRow;
            MessageBox.Show("Prueba");
        }

        private void dgDatos_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            //int index = this.dgDatos.SelectedCells[0].Column.DisplayIndex;

            //var indexgg = this.dgDatos.SelectedCells[0].Item;
            //string dato= ((System.Data.DataRowView)indexgg).Row[0].ToString();
            //string dato1 = ((System.Data.DataRowView)indexgg).Row.RowState.ToString();

            //var rowIndex = this.dgDatos.Items.IndexOf(this.dgDatos.SelectedItem);
        }

        // ------    DoubleClick      ------ //
        private void Row_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {           
            //var rowIndex1 = this.dgDatos.Items.IndexOf(this.dgDatos.SelectedItem);

            int columna = this.dgDatos.SelectedCells[0].Column.DisplayIndex;
            if (columna == 0)
            {
                var registro = this.dgDatos.SelectedCells[0].Item;
                string celda = ((System.Data.DataRowView)registro).Row[columna].ToString();

                FormasDepago.TrxVentas.VarTiendaIni = celda;

                string fechainicialC = FechaInicial.Text;
                fechainicialC = fechainicialC.Substring(8, 2) + fechainicialC.Substring(3, 2) + fechainicialC.Substring(0, 2);
                string fechafinalC = FechaFinal.Text;
                fechafinalC = fechafinalC.Substring(8, 2) + fechafinalC.Substring(3, 2) + fechafinalC.Substring(0, 2);
                FormasDepago.TrxVentas.VarFechaInicial = fechainicialC;
                FormasDepago.TrxVentas.VarFechaFinal = fechafinalC;

                cont1 = cont1 + 1;
                if (cont1 < 2)
                {
                    TrxVentas objeto = new TrxVentas(cont1);
                    objeto.Show();
                }
                else
                {
                    //System.Windows.MessageBox.Show("La ventana ya esta abierta...");
                    Card01.Visibility = Visibility;
                    btCerrarAbieta.Focus();
                }

                //string dato1 = ((System.Data.DataRowView)indexgg).Row.RowState.ToString();

                //var rowIndex = this.dgDatos.Items.IndexOf(this.dgDatos.SelectedItem);

                //DependencyObject dep = (DependencyObject)e.OriginalSource;

                // Seleccion de Renglon
                //int index1 = this.dgDatos.SelectedCells[0].Column.DisplayIndex;
                //this.dgDatos.SelectedIndex = index1;

                //int columnIndex = cell.Column.DisplayIndex;
                //System.Windows.Controls.DataGridCell cell = new System.Windows.Controls.DataGridCell();
            }
        }

        private void dgDatos_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        {
            //MessageBox.Show("dgDatos_ContextMenuOpening");
        }

        private void dgDatos_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //string dato = dgDatos.ToString();
            //MessageBox.Show("dgDatos_SelectionChanged");
            ////ProductItem productItem = (ProductItem)dgDatos.SelectedItem; //Datagrid bound with ProductItem
            //var rowIndex = this.dgDatos.Items.IndexOf(this.dgDatos.SelectedItem);
        }

        private void dgDatos_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            //DependencyObject dep = (DependencyObject)e.OriginalSource;

            ////Stepping through the visual tree
            //while ((dep != null) && !(dep is System.Windows.Controls.DataGridCell))
            //{
            //    dep = VisualTreeHelper.GetParent(dep);
            //}

            ////Is the dep a cell or outside the bounds of Window1?
            //if (dep == null | !(dep is System.Windows.Controls.DataGridCell))
            //{
            //    return;
            //}
            //else
            //{
            //    System.Windows.Controls.DataGridCell cell = new System.Windows.Controls.DataGridCell();
            //    cell = (System.Windows.Controls.DataGridCell)dep;
            //    while ((dep != null) && !(dep is DataGridRow))
            //    {
            //        dep = VisualTreeHelper.GetParent(dep);
            //    }

            //    if (dep == null)
            //    {
            //        return;
            //    }
            //    int colindex = cell.Column.DisplayIndex;
            //    var rowIndex = this.dgDatos.Items.IndexOf(this.dgDatos.SelectedItem);
            //    //int rowindex1 = ;

            //    DataGridRow row = dep as DataGridRow;
            //    //int rowindex = DataGrid.ItemContainerGenerator.IndexFromContainer(row);

            //    //ClickedItemDisplay = colindex + ", " + rowindex;
            //}
        }

        private void dgDatos_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            //DependencyObject dep = (DependencyObject)e.OriginalSource;

            //// iteratively traverse the visual tree
            //while ((dep != null) && !(dep is DataGridCell) && !(dep is DataGridColumnHeader))
            //{
            //    dep = VisualTreeHelper.GetParent(dep);
            //}

            //if (dep == null)
            //    return;

            //if (dep is DataGridColumnHeader)
            //{
            //    DataGridColumnHeader columnHeader = dep as DataGridColumnHeader;
            //    // do something
            //}

            //if (dep is DataGridCell)
            //{
            //    DataGridCell cell = dep as DataGridCell;

            //    // navigate further up the tree
            //    while ((dep != null) && !(dep is DataGridRow))
            //    {
            //        dep = VisualTreeHelper.GetParent(dep);
            //    }

            //    DataGridRow row = dep as DataGridRow;

            //    string dato = cell.ToString();
           

            //    int columnIndex = cell.Column.DisplayIndex;
            //    var rowIndex = this.dgDatos.Items.IndexOf(this.dgDatos.SelectedItem);
            //    DataGridRow rowg = dep as DataGridRow;
            //    //int rowindex = DataGrid.ItemContainerStyleProperty.GlobalIndex(rowg);

            //    MessageBox.Show(dato);

            //}
        }
    }
}
