﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FormasDepago
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        string usuario = string.Empty;
        string password = string.Empty;
        System.Data.DataTable tbLogin = null;

        public Login()
        {
            InitializeComponent();
            txt_usuario.Focus();
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            App.Current.Shutdown();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

            try
            {
                tbLogin = null;

                usuario = txt_usuario.Text;
                SecureString myPass = txt_contraseña.SecurePassword;
                var pass = (PasswordBox)txt_contraseña;
                password = pass.Password;

                tbLogin = Fdp.Negocio.FormasDepago.FormasDepago.GetInstance().ObtenLogin1(usuario, password);

                if (tbLogin != null)
                {
                    foreach (DataRow row in tbLogin.Rows)
                    {
                        string USRNOM;
                        string USRVIL;
                        string USRMAR;
                        string USRCOM;

                        USRNOM = row["USRNOM"].ToString();
                        USRVIL = row["USRVIL"].ToString();
                        USRMAR = row["USRMID"].ToString();
                        USRCOM = row["USRCOM"].ToString();

                        FormasDepago.MainWindow.VarNombre   = USRNOM;
                        FormasDepago.MainWindow.VarUsuario  = usuario;
                        FormasDepago.MainWindow.VarPassword = password;

                    }

                    if (tbLogin.Rows.Count > 0)
                    {
                        MainWindow objeto = new MainWindow();
                        objeto.Show();
                        this.Visibility = Visibility.Hidden;
                    }
                }
            }
            catch (Exception ex)
            {
                string Msg = ex.Message.ToString();
                MessageBox.Show(Msg);             
            }
        }

        private void txt_contraseña_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                // Carga de Datos
                try
                {

                    try
                    {
                        tbLogin = null;

                        usuario = txt_usuario.Text;
                        SecureString myPass = txt_contraseña.SecurePassword;
                        var pass = (PasswordBox)txt_contraseña;
                        password = pass.Password;

                        tbLogin = Fdp.Negocio.FormasDepago.FormasDepago.GetInstance().ObtenLogin1(usuario, password);

                        if (tbLogin != null)
                        {
                            foreach (DataRow row in tbLogin.Rows)
                            {
                                string USRNOM;
                                string USRVIL;
                                string USRMAR;
                                string USRCOM;

                                USRNOM = row["USRNOM"].ToString();
                                USRVIL = row["USRVIL"].ToString();
                                USRMAR = row["USRMID"].ToString();
                                USRCOM = row["USRCOM"].ToString();

                                FormasDepago.MainWindow.VarNombre = USRNOM;
                                FormasDepago.MainWindow.VarUsuario = usuario;
                                FormasDepago.MainWindow.VarPassword = password;

                            }

                            if (tbLogin.Rows.Count > 0)
                            {
                                MainWindow objeto = new MainWindow();
                                objeto.Show();
                                this.Visibility = Visibility.Hidden;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        string Msg = ex.Message.ToString();
                        MessageBox.Show(Msg);
                    }
                }
                catch { }
            }
        }
    }
}
