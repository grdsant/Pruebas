﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fdp.Negocio.FechasProceso
{
    public class FechasProceso
    {
        internal static FechasProceso FechasProcesos;

        public static FechasProceso GetInstance()
        {
            if (FechasProcesos == null)
                FechasProcesos = new FechasProceso();
            return FechasProcesos;
        }

        public DataTable ObtenDatos(string fechaInicial, string fechaFinal)
        {
            try
            {
                return Fdp.Datos.FechasProceso.FechasProceso.ObtenerDatos(fechaInicial, fechaFinal);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string ProcesaFecha(string fechaInicial, string fechaFinal)
        {
            try
            {
                return Fdp.Datos.FechasProceso.FechasProceso.ProcesarFechas(fechaInicial, fechaFinal);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
