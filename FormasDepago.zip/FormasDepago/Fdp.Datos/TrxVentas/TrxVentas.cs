﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;
using System.Data;

namespace Fdp.Datos.TrxVentas
{
    public class TrxVentas
    {
        #region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        #endregion

        public static DataTable ObtenerDatos(string fechaInicial, string fechaFinal, string tienda, string usuario)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtTrxXtienda = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL MMSATPGM.SAT211C11 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", usuario.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL MMSATPGM.SAT211R11 (\n");
                sql.AppendFormat("X'" + "{0}" + "F'" + "," + "\n", tienda.PadLeft(5, '0'));
                sql.AppendFormat("X'0" + "{0}" + "F'" + "," + "\n", fechaInicial.PadLeft(6, '0'));
                sql.AppendFormat("X'0" + "{0}" + "F'" + "," + "\n", fechaFinal.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", usuario.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL MMSATPGM.SAT211C12 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", usuario.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT  * \n");

                sql.Append("FROM MMSATOBJ.SAT211F11 \n");
                sql.AppendFormat(" WHERE  TRXFCH <> 0 \n");
                if (tienda != "") { sql.AppendFormat("and TRXSTR = " + "{0}" + "\n", tienda); }
                if (fechaInicial != "") { sql.AppendFormat("and TRXFCH between " +  "{0}" + "\n", fechaInicial); }
                if (fechaFinal != "") { sql.AppendFormat(" and " + "{0}" + "\n", fechaFinal); }

                sql.Append(" ORDER BY TRXSTR, TRXFCH, TRXTIM  \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtTrxXtienda = new DataTable("TransaccionesXtienda");
                dtTrxXtienda.Load(db2Reader);
                db2Reader.Close();

                return dtTrxXtienda;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

    }
}
