﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;
using System.Data;

namespace Fdp.Datos.FormasDepago
{
    public class FormasDepago
    {
        #region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        public static string Servidor = ConfigurationManager.ConnectionStrings["IPservidor"].ToString();

        // Ambiente
        #endregion

        public static DataTable ObtenerDatos(string fechaInicial, string fechaFinal, string tienda, string nivel, string usuario)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtFormasDepago = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL MMSATPGM.SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (tienda == "9999")
                {
                    tienda = "0";
                }

                if (nivel != "1")
                {
                    sql.Clear();
                    sql.Append("CALL MMSATPGM.SAT211R4 (\n");
                    sql.AppendFormat("x'0" + "{0}" + "f'" + "," + "\n", fechaInicial.PadLeft(6, '0'));
                    sql.AppendFormat("x'0" + "{0}" + "f'" + "," + "\n", fechaFinal.PadLeft(6, '0'));
                    sql.AppendFormat("x'" + "{0}" + "f'" + "," + "\n", tienda.PadLeft(5, '0'));
                    sql.AppendFormat("x'" + "{0}" + "f'" + "," + "\n", nivel.PadLeft(5, '0'));
                    sql.AppendFormat("'" + "{0}" + "'" + "\n", usuario.PadRight(10, ' '));
                    sql.Append(")");

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();
                }

                if (nivel != "1")
                {
                    sql.Clear();
                    sql.Append("CALL MMSATPGM.SAT211C1 (\n");
                    sql.AppendFormat("'" + "{0}" + "'" + "\n", usuario.PadRight(10, ' '));
                    sql.Append(")");

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();
                }

                sql.Clear();
                sql.Append("SELECT   \n");
                if (nivel == "1")
                {
                    #region campos
                    sql.Append("CUPSTR, \n"); //00
                    sql.Append("0 CUPMES, \n"); //00
                    sql.Append("CUPFCH, \n"); //00
                    sql.Append("CUPQTY, \n"); //00
                    sql.Append("CUPNTI, \n"); //00
                    sql.Append("CUPTPP, \n"); //00
                    sql.Append("CUPINV, \n"); //00
                    sql.Append("CUPCST, \n"); //00
                    sql.Append("CUPVSE, \n"); //00
                    sql.Append("CUPVNE, \n"); //00
                    sql.Append("CUPVTC, \n"); //00
                    sql.Append("CUPVTM, \n"); //00
                    sql.Append("CUPVTE, \n"); //00
                    sql.Append("CUPDVC, \n"); //00
                    sql.Append("CUPDVE, \n"); //00
                    sql.Append("CUPDSM, \n"); //00
                    sql.Append("CUPRBD, \n"); //00
                    sql.Append("CUPABI, \n"); //00
                    sql.Append("CUPASI, \n"); //00
                    sql.Append("CUPVTN, \n"); //00
                    sql.Append("CUPIVN, \n"); //00
                    sql.Append("CUPVTA, \n"); //00
                    sql.Append("CUPITA, \n"); //00
                    sql.Append("CUPSRV, \n"); //00
                    sql.Append("CUPCSV, \n"); //00
                    sql.Append("CUPDAA, \n"); //00
                    sql.Append("CUPDAC, \n"); //00
                    sql.Append("CUPTOA, \n"); //00
                    sql.Append("CUPFLA, \n"); //00
                    sql.Append("CUPEGR, \n"); //00
                    sql.Append("CUPEPE, \n"); //00
                    sql.Append("CUPEPN, \n"); //00
                    sql.Append("CUPEPL, \n"); //00
                    sql.Append("CUPEVI, \n"); //00
                    sql.Append("CUPEGP, \n"); //00
                    sql.Append("CUPEDN, \n"); //00
                    sql.Append("CUPEMT, \n"); //00
                    sql.Append("CUPESS, \n"); //00
                    sql.Append("CUPPTM, \n"); //00
                    sql.Append("CUPPCM, \n"); //00
                    sql.Append("CUPDRP, \n"); //00
                    sql.Append("CUPCMY, \n"); //00
                    sql.Append("CUPFCP, \n"); //00
                    sql.Append("CUPFHC, \n"); //00
                    sql.Append("CUPFDB, \n"); //00
                    sql.Append("CUPFDR, \n"); //00
                    sql.Append("CUPFGC, \n"); //00
                    sql.Append("CUPVCR, \n"); //00
                    sql.Append("CUPFCA, \n"); //00
                    sql.Append("CUPFTB, \n"); //00
                    sql.Append("CUPTVI, \n"); //00

                    sql.Append("CUPTDE, \n"); //00
                    sql.Append("CUPTCR, \n"); //00

                    sql.Append("CUPTMC, \n"); //00
                    sql.Append("CUPTMM, \n"); //00
                    sql.Append("CUPTTC, \n"); //00
                    sql.Append("CUPFCM, \n"); //00
                    sql.Append("CUPIXD, \n"); //00
                    sql.Append("CUPFVL, \n"); //00
                    sql.Append("CUPFV1, \n"); //00
                    sql.Append("CUPFV2, \n"); //00
                    sql.Append("CUPFV3, \n"); //00
                    sql.Append("CUPFV4, \n"); //00
                    sql.Append("CUPFV5, \n"); //00
                    sql.Append("CUPFV6, \n"); //00
                    sql.Append("CUPFV7, \n"); //00
                    sql.Append("CUPFV8, \n"); //00
                    sql.Append("CUPFV9, \n"); //00
                    sql.Append("CUPFFA, \n"); //00
                    sql.Append("CUPFVE, \n"); //00
                    sql.Append("CUPFFN, \n"); //00
                    sql.Append("CUPMAR, \n"); //00
                    sql.Append("CUPST \n"); //00
                    #endregion

                    sql.Append(" FROM MMSATOBJ.SAT211F4 \n");
                }
                else
                {
                    sql.Append(" * FROM MMSATOBJ.SAT211F7 \n");
                }

                if (nivel == "1")
                {
                    sql.AppendFormat(" WHERE  CUPFCH <> 0 \n");
                }

                if (nivel == "1")
                {
                    if (tienda != "0") { sql.AppendFormat("and CUPSTR = " + "{0}" + "\n", tienda); }
                }
                else
                {
                    if (tienda != "0") { sql.AppendFormat("WHERE CUPSTR = " + "{0}" + "\n", tienda); }
                }
                if (nivel == "1")
                {
                    if (fechaInicial != "") { sql.AppendFormat("and CUPFCH between " + "{0}" + "\n", fechaInicial); }
                    if (fechaFinal != "") { sql.AppendFormat(" and " + "{0}" + "\n", fechaFinal); }
                }
                sql.Append(" ORDER BY CUPSTR, CUPFCH  \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtFormasDepago = new DataTable("FormasDepago");
                dtFormasDepago.Load(db2Reader);
                DataRow row = dtFormasDepago.NewRow();

                row["CUPSTR"] = 99999;
                //if (nivel != "1")
                //{
                    row["CUPMES"] = 0;
                //}
                row["CUPFCH"] = 0;
                row["CUPQTY"] = 0;
                row["CUPNTI"] = 0;
                row["CUPTPP"] = 0;
                row["CUPINV"] = 0;
                row["CUPCST"] = 0;
                row["CUPVSE"] = 0;
                row["CUPVNE"] = 0;
                row["CUPVTC"] = 0;
                row["CUPVTM"] = 0;
                row["CUPVTE"] = 0;
                row["CUPDVC"] = 0;
                row["CUPDVE"] = 0;
                row["CUPDSM"] = 0;
                row["CUPRBD"] = 0;
                row["CUPABI"] = 0;
                row["CUPASI"] = 0;
                row["CUPVTN"] = 0;
                row["CUPIVN"] = 0;
                row["CUPVTA"] = 0;
                row["CUPITA"] = 0;
                row["CUPSRV"] = 0;
                row["CUPCSV"] = 0;
                row["CUPDAA"] = 0;
                row["CUPDAC"] = 0;
                row["CUPTOA"] = 0;
                row["CUPFLA"] = 0;
                row["CUPEGR"] = 0;
                row["CUPEPE"] = 0;
                row["CUPEPN"] = 0;
                row["CUPEPL"] = 0;
                row["CUPEVI"] = 0;
                row["CUPEGP"] = 0;
                row["CUPEDN"] = 0;
                row["CUPEMT"] = 0;
                row["CUPESS"] = 0;
                row["CUPPTM"] = 0;
                row["CUPPCM"] = 0;
                row["CUPDRP"] = 0;
                row["CUPCMY"] = 0;
                row["CUPFCP"] = 0;
                row["CUPFHC"] = 0;
                row["CUPFDB"] = 0;
                row["CUPFDR"] = 0;
                row["CUPFGC"] = 0;
                row["CUPVCR"] = 0;
                row["CUPFCA"] = 0;
                row["CUPFTB"] = 0;
                row["CUPTVI"] = 0;

                row["CUPTDE"] = 0;
                row["CUPTCR"] = 0;

                row["CUPTMC"] = 0;
                row["CUPTMM"] = 0;
                row["CUPTTC"] = 0;
                row["CUPFCM"] = 0;
                row["CUPIXD"] = 0;
                row["CUPFVL"] = 0;
                row["CUPFV1"] = 0;
                row["CUPFV2"] = 0;
                row["CUPFV3"] = 0;
                row["CUPFV4"] = 0;
                row["CUPFV5"] = 0;
                row["CUPFV6"] = 0;
                row["CUPFV7"] = 0;
                row["CUPFV8"] = 0;
                row["CUPFV9"] = 0;
                row["CUPFFA"] = 0;
                row["CUPFVE"] = 0;
                row["CUPFFN"] = 0;
                row["CUPMAR"] = " ";
                if (nivel == "1")
                {
                    row["CUPST"] = " ";
                }
                dtFormasDepago.Rows.Add(row);

                db2Reader.Close();

                return dtFormasDepago;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static Dictionary<string, string> ObtenTiendas()
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            Dictionary<string, string> diTiendas = new Dictionary<string, string>();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT CHAR(STRNUM), CONCAT(CHAR(STRNUM), STRNAM) FROM " + "MM610LIB.TBLSTR ORDER BY STRNUM \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();
                if (db2Reader.Read())
                {
                    db2Reader.Close();
                }
                db2Reader = db2Comm.ExecuteReader();
                diTiendas.Add("9999", "9999 Todas");
                while (db2Reader.Read())
                {
                    diTiendas.Add(db2Reader.GetString(0), db2Reader.GetString(1));
                }
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return diTiendas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenLogin(string ParUsuario, string ParPassword)
        {
            Servidor = ConfigurationManager.ConnectionStrings["IPservidor"].ToString();
            string cadenaConexionDb2 = "Provider=IBMDA400;Data Source=" + Servidor + ";User Id=" + ParUsuario + " ;Password=" + ParPassword;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtLogin = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL MMSATPGM.SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL MMSATPGM.SAT177R3 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParUsuario.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT * FROM MMSATOBJ.SAT177F3\n");
                sql.Append(" ORDER BY USRUSR ASC\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtLogin = new DataTable("Login");
                dtLogin.Load(db2Reader);
                db2Reader.Close();
            }

            catch (OleDbException ex)
            {        
                throw ex;
            }

            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return dtLogin;
        }
    }
}
